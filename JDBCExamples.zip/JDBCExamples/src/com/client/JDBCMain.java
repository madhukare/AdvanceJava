package com.client;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCMain {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		// Loading Driver

		Class.forName("com.mysql.jdbc.Driver");

		// Establishing Connection

		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/day3", "root", "root");
		System.out.println("Connection Established: " + c);

		// Create a Statement

		Statement st = c.createStatement();

		// Execute Queries

		// st.executeUpdate("create table student(id int,name varchar(20),marks
		// int)");
		//int res = st.executeUpdate("insert into student values(1,'virat',699)");//Single Query

		/*if (res != 0) {
			System.out.println("Inserted");
		} else {
			System.out.println("Not Inserted");
		}*/

		/*st.addBatch("insert into student values(2,'sindhu',700)");//Multiple Queries
		st.addBatch("insert into student values(3,'nidhi',705)");
		st.addBatch("update student set name='pravs', marks=750 where id=1");
		st.addBatch("delete from student where id=2");

		int[] res=st.executeBatch();
		for (int i : res) {
			System.out.println(i);
		}*/
		
		ResultSet rs=st.executeQuery("select * from student");
		
		while(rs.next()){
			
			System.out.println(rs.getInt(1)+" "+rs.getString("name")+" "+rs.getInt("marks"));
		}
		
		// Closing Connections

		c.close();

	}

}
