package com.prepared;

import java.sql.SQLException;
import java.util.List;

public class ClientApp {
	public static void main(String args[]) throws ClassNotFoundException, SQLException {

		// System.out.println(CrudOperations.insertRecord(101, "sindhu", 850));
		/*
		  Student st = new Student(102, "swetha", 900);
		  System.out.println(CrudOperations.insertStudent(st));
		 */
		/*
		 Student st1 = new Student();
		 System.out.println(CrudOperations.updateStudentWithId(st1));
		 */
		/*
		 System.out.println(CrudOperations.deleteStudentWithId(101));
		 */
		//System.out.println(CrudOperations.getStudentWithId(1));
		//System.out.println(CrudOperations.getStudentWithName("pravs"));
		//System.out.println(CrudOperations.getNameWithId(3));
		/*List<Student> li = CrudOperations.getAllStudentDetails();
		for (Student st : li) {
			System.out.println(st);
		}*/
		CrudOperations.getAllStudents();
	}
}
