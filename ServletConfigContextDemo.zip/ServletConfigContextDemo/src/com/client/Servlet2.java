package com.client;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Servlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ServletConfig config = getServletConfig();
		String id = config.getInitParameter("TraineeId");
		String name = config.getInitParameter("TraineeName");
		PrintWriter out = response.getWriter();
		out.println("Message from Servlet2");
		out.println("id : " + id);
		out.println("name : " + name);
		
		ServletContext context=getServletContext();
		String tn=context.getInitParameter(("Trainer name"));
		String org=context.getInitParameter("Org");
		out.println("Message from Servlet 1");
		out.println("Trainer Name : "+ tn);
		out.println("Org : "+org);
		
	}

}
