package com.session;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



@WebServlet("/SessionDemo")
public class SessionDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);

	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Creating a Session object
		HttpSession se=request.getSession();
		PrintWriter out=response.getWriter();
		out.print("Session ID: "+se.getId());
		
		//Collecting data from html
		String name=request.getParameter("uname");
		String branch=request.getParameter("ubranch");
		
		//Storing data in session obj
		se.setAttribute("un", name);
		se.setAttribute("ub", branch);
		out.print("Creation Time of Session: "+se.getCreationTime());;
		out.print("Last Accessed Time of Session: "+se.getLastAccessedTime());
		
		
		//se.invalidate();//Destroying Session
		//out.print("Session Id after Destruction: "+se.getId());
		
		RequestDispatcher rd=request.getRequestDispatcher("S2");
		rd.include(request, response);
	}

}
