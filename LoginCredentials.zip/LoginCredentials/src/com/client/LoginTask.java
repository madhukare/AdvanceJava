package com.client;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginTask")
public class LoginTask extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String email=request.getParameter("t1");
		String Password=request.getParameter("t2");
		String pwd="Sindhu";
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		RequestDispatcher rd=null;
		if(Password.equals(pwd)){
			out.println("Welcome to the User");
			out.println("<br>");
			request.setAttribute("Email", email);//stored data in request scope
			rd=request.getRequestDispatcher("/DetailsServlet");
			rd.include(request, response);
		}
		else{
			out.println("Invalid Credentials");
			 rd=request.getRequestDispatcher("index.html");
			rd.include(request, response);
		}

	}

}
