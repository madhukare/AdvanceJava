import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class HospitalFinder {

	public static void main(String[] args) {
		
		HospitalService service=new HospitalService();
		
		List<String> list=new ArrayList<>();
		
		
		list.add("Cardiac");
		list.add("ENT");
		list.add("Ortho");
		list.add("Pediatric");
		list.add("Gastro");
		
		System.out.println(service.addHospital("YASHODA", list, "MATHEWS", "9848222222","Sec"));
		System.out.println(service.addHospital("CITIZENS", list, "VIJAY", "9848222266","KKP"));
		
		System.out.println("=========Hospital Map===========");
		System.out.println(service.getHospitals());
		
		System.out.println("enter code");
		Scanner sc=new Scanner(System.in);
		int code=sc.nextInt();
		System.out.println("=============Hospital Details=========");
		System.out.println(service.getHospitalDetails(code));
	}

}
