package collections;

import java.util.ArrayList;
import java.util.List;

public class ListDemo {

	public static void main(String[] args) {

		List<Integer> leapyear=new ArrayList<Integer>();
		leapyear.add(1996);
		leapyear.add(2000);
		leapyear.add(2004);
		leapyear.add(2008);
		leapyear.add(2012);
		System.out.println(leapyear);
		System.out.println("list of size "+ leapyear.size());
		System.out.println(leapyear.get(1));
		//System.out.println(leapyear.remove(2));
		leapyear.remove(4);
		//System.out.println(leapyear);
		leapyear.remove(new Integer(2004));
		System.out.println(leapyear);
		System.out.println("===============");
		for(Integer i:leapyear)
			System.out.println(i);
		

	}

}
