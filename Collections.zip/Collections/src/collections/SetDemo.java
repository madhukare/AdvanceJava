package collections;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {

		Set<String> colorSet = new HashSet<>();
		Set<String> color = new TreeSet<>();
		color.add("black");
		color.add("brown");
		String s = null;
		colorSet.add("red");
		colorSet.add("yellow");
		colorSet.add("blue");
		colorSet.add("blue");
		colorSet.add(s);

		System.out.println("Size : " + colorSet.size());
		System.out.println(" ");

		System.out.println("Remove :" + colorSet.remove(null));

		for (String obj : colorSet)
			System.out.println(obj);

		System.out.println(colorSet.removeAll(colorSet));
		System.out.println(" ");

		System.out.println(colorSet.addAll(color));
		System.out.println(" ");
		
		System.out.println(color);

	}

}
