package collections;

public class CabCustomerServiceTester {

	public static void main(String[] args) {
		CabCustomerService service = new CabCustomerService();

		CabCustomer c1 = new CabCustomer("sindhu", "Lingampally", "Gachibowli", 2, 9876543210l);
		service.addCabCustomer(c1);

		CabCustomer c2 = new CabCustomer("nidhi", "Lingampally", "Gachibowli", 6, 9876543210l);
		service.addCabCustomer(c2);

		CabCustomer c3 = new CabCustomer("varsha", "Lingampally", "Gachibowli", 6, 9876543208l);
		// service.addCabCustomer(c3);

		System.out.println(service.getClist());
		/*
		 * List<CabCustomer> list = service.getClist();
		 * 
		 * for (CabCustomer c : list) System.out.println(c);
		 */

		System.out.println(service.isFirstCustomer(c3));
		// System.out.println(service.calculateBill(c2));
		System.out.println(service.printBill(c2));

		/*
		 * for (CabCustomer c : list) {
		 * 
		 * System.out.println(c.getCustomerName() +
		 * " please pay your bill of Rs." + service.printBill(c)); }
		 */
		// service.printBill(c3);
		// System.out.println(c3.getCustomerName()+" please pay your bill of Rs:
		// "+service.printBill(c3));

	}

}
