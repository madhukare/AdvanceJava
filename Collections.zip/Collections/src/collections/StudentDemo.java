package collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class StudentDemo {
	public static void main(String[] args) {

		List<Student> stdlist = new ArrayList<Student>();

		Student s1 = new Student("sindhu", 93, 90, 87);
		Student s2 = new Student("nidhi", 89, 85, 70);
		Student s3 = new Student("sweta", 87, 90, 85);

		stdlist.add(s1);
		stdlist.add(s2);
		stdlist.add(s3);
		stdlist.add(new Student("pravallika", 87, 86, 76));
		
		Iterator<Student> itr=stdlist.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		
		System.out.println(" ");
		
		for (Student st : stdlist)
			System.out.println(st);

		System.out.println(" ");

		for (Student s : stdlist)
			System.out.println("Id: " + s.getId() + " Name: " + s.getName() + " Percentage: " + s.calcPercentage());

		System.out.println(" ");

		for (Student stu : stdlist) {
			if (stu.calcPercentage() >= 90)
				System.out.println(
						"Id: " + stu.getId() + " Name: " + stu.getName() + " Percentage: " + stu.calcPercentage());
		}

	}
}
