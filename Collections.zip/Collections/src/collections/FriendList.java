package collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FriendList {

	public static void main(String[] args) {
		List<String> flist=new ArrayList<>();
		flist.add("sindhu");
		flist.add("nidhi");
		flist.add("swetha");
		flist.add("pravallika");
		flist.add("madhukar");
		flist.add("uday");
		System.out.println(flist);
		Collections.sort(flist);
		System.out.println(flist);
		Collections.reverse(flist);
		System.out.println(flist);
		
	}

}
