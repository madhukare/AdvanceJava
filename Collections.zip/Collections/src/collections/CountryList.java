package collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CountryList {

	public static void main(String[] args) {

		List<String> countrylist = new ArrayList<String>();

		countrylist.add("India");
		countrylist.add("USA");
		countrylist.add("Canada");
		countrylist.add("Sweden");
		countrylist.add("Australia");
		countrylist.add("UK");

		System.out.println(countrylist);
		System.out.println("list of size: " + countrylist.size());
		System.out.println(countrylist.get(2));

		countrylist.remove(3);
		System.out.println(countrylist);

		countrylist.remove(new String("USA"));
		System.out.println(countrylist);
		System.out.println("=========");
		for (String i : countrylist)
			System.out.println(i);

	}

}
