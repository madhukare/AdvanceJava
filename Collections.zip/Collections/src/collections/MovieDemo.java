package collections;

import java.util.HashSet;
import java.util.Set;

public class MovieDemo {

	public static void main(String[] args) {

		Set<Movie> mSet = new HashSet<>();

		Movie m1 = new Movie("Bahubali", "Rajamouli", 180, 4.7);
		Movie m2 = new Movie("sye", "Rajamouli", 160, 4.3);
		Movie m3 = new Movie("saira", "surendar", 150, 4.5);

		mSet.add(m1);
		mSet.add(m2);
		mSet.add(m3);
		mSet.add(m1);//duplicate object

		for (Movie m : mSet)
			System.out.println(m);

	}

}
