package collections;

import java.util.ArrayList;
import java.util.List;

public class CabCustomerService {
	
	long phone = 0;

	private List<CabCustomer> clist = new ArrayList<>();

	public List<CabCustomer> getClist() {
		return clist;
	}

	public void addCabCustomer(CabCustomer c) {
		if(isFirstCustomer(c))
			clist.add(c);
	}

	public boolean isFirstCustomer(CabCustomer c1) {
		for (CabCustomer c : clist)
		{
			if (c.getPhone() == c1.getPhone())
				return false;
		}
			return true;
	}

	public double calculateBill(CabCustomer obj) {

		if (isFirstCustomer(obj))
			return 0;

		else if (obj.getDistance() <= 4)
			return  80;

		else 
			return (80 + (obj.getDistance() - 4) * 6);
		
	}

	public String printBill(CabCustomer c) {

		return c.getCustomerName()+ " please pay your bill of Rs: "+calculateBill(c);
	}
}
