import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class HospitalService {

	List<Hospital>hlist=new ArrayList<>();
	
	Map<Integer,String> map=new HashMap<Integer,String>();
	
	public int addHospital(String hospitalName, List<String> listOfTreatments, String contactPerson, String contactNumber,
			String location)
	{
		Hospital h=new Hospital(hospitalName,listOfTreatments,contactPerson,contactNumber,location);
		
		hlist.add(h);
		
		return h.getHospitalCode();
		
	}
		
	public Map<Integer,String> getHospitals()
	{
		for(Hospital h: hlist){
			map.put(h.getHospitalCode(), h.getHospitalName());
		}
		return map;
	}
	
	public Hospital getHospitalDetails( int Code )
	{
		
		for(Hospital h:hlist)
		{
			if(h.getHospitalCode()==Code)
				return h;
		}
		return null;
		
	}
	

}
