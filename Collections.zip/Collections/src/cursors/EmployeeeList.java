package cursors;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class EmployeeeList {

	public static void main(String[] args) {

		List<Employee> emplist = new ArrayList<>();
		List<Employee> fresherlist = new ArrayList<>();

		emplist.add(new Employee("Sindhu", 22000, "developer"));
		emplist.add(new Employee("nidhi", 44000, "Testing"));
		emplist.add(new Employee("sweeta", 45000, "Analyst"));
		emplist.add(new Employee("pravi", 20000, "Testing"));
		emplist.add(new Employee("Madhu", 55000, "Analyst"));
		emplist.add(new Employee("Uday", 75000, "Hr"));
		emplist.add(new Employee("Rohith", 20000, "Testing"));
		emplist.add(new Employee("Ajay", 23000, "Testing"));
		emplist.add(new Employee("shiva", 70000, "Developer"));
		emplist.add(new Employee("jagadeesh", 20000, "Support"));

		System.out.println("=========Employee List========");
		for (Employee e : emplist)
			System.out.println(e);

		System.out.println(" ");

		Iterator<Employee> itr = emplist.iterator();
		while (itr.hasNext()) {
			Employee e = itr.next();
			if (e.getSalary() < 25000) {
				itr.remove();
				fresherlist.add(e);
			}

		}

		System.out.println(" ");
		System.out.println("=========After Deletion========");
		for (Employee e : emplist)
			System.out.println(e);

		System.out.println(" ");

		System.out.println("=========Fresher List========");
		for (Employee e : fresherlist) 
		{

			System.out.println(e);
		}
		System.out.println(" ");
		
		System.out.println("=========Fresher List after Increment========");
		for (Employee e : fresherlist) 
		{
			e.setSalary(e.getSalary() + 10000);
			System.out.println(e);
		}

	}

}
