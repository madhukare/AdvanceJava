package cursors;

public class Employee {

	private int id;
	private String name;
	private int Salary;
	private String dept;

	static int idGenerator;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return Salary;
	}

	public void setSalary(int salary) {
		Salary = salary;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public int getId() {
		return id;
	}

	public static int getIdGenerator() {
		return idGenerator;
	}

	public Employee() {
		super();
		this.id = ++idGenerator;
	}

	public Employee(String name, int salary, String dept) {
		super();
		this.name = name;
		Salary = salary;
		this.dept = dept;
		this.id = ++idGenerator;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", Salary=" + Salary + ", dept=" + dept + "]";
	}

}
