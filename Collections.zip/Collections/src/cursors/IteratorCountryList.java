package cursors;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class IteratorCountryList {

	public static void main(String[] args) {
		List<String> countrylist = new ArrayList<String>();
		
		countrylist.add("India");
		countrylist.add("USA");
		countrylist.add("Canada");
		countrylist.add("Sweden");
		countrylist.add("Australia");
		countrylist.add("UK");
		
		Iterator<String> itr=countrylist.iterator();
		 while(itr.hasNext())
		 {
			 String s=itr.next();
			 System.out.println(itr.next());
			
		 }

	}

}
