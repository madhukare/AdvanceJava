package mapInterface;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class PhoneNumber {

	public static void main(String[] args) {
		
		Map<String,Long> phoneMap=new HashMap<String,Long>();
		
		phoneMap.put("Sindhu", 9010768696l);
		phoneMap.put("Nidhi", 8978187621l);
		phoneMap.put("Swetha", 9876543210l);
		phoneMap.put("Pravallika",8765432190l );
		
		Set<Entry<String,Long>> entrySet=phoneMap.entrySet();
		for(Entry<String,Long> e: entrySet)
			System.out.println(e.getKey() + " " +e.getValue());
		
		
	}

}
