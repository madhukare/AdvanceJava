package mapInterface;

public class Book {

	private int id;
	private String name;
	private String author;
	static int idGenerator;

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public static void setIdGenerator(int idGenerator) {
		Book.idGenerator = idGenerator;
	}

	public Book() {
		super();
		this.id = ++idGenerator;
	}

	public Book(String name, String author) {
		super();
		this.id = ++idGenerator;
		this.name = name;
		this.author = author;
	}

	@Override
	public String toString() {
		return "Book [id=" + id + ", name=" + name + ", author=" + author + "]";
	}

}
