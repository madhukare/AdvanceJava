package mapInterface;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class BookMap {

	public static void main(String[] args) { 
		
		Map<String,Integer> book=new TreeMap<String,Integer>();
		
		book.put("Harry Potter",1500);
		book.put("The Girl who knew too much",4500);
		book.put("Game of Thrones",5870);
		
		for(Entry<String, Integer> e: book.entrySet())
			System.out.println(e.getKey()+ " " +e.getValue());
		
		System.out.println(" ");
		
		System.out.println("-------Entry to Set----------");
		
		Set<Entry<String, Integer>> entry=book.entrySet();//Step 1
		System.out.println(entry);
		
		System.out.println(" ");
		
		System.out.println("-------Set to List----------");
		
		List<Entry<String, Integer>> list=new ArrayList<>(entry);//Step 2
		System.out.println(list);
		
		/*List<Entry<String, Integer>> entryList1=new ArrayList<>();//Step2 another method
		for(Entry<String, Integer> e:entry)
			entryList1.add(e);
		System.out.println(entryList1);*/
		
		System.out.println(" ");
		
		System.out.println("-------List sorting----------");
		
		Collections.sort(list,new SortByValue());//Sort by value
		System.out.println(list);
		
		System.out.println(" ");
		
		System.out.println("---------List to Map----------");
		
		LinkedHashMap<String, Integer> linkedMap=new LinkedHashMap<>();
		for(Entry<String, Integer> e:list)
			linkedMap.put(e.getKey(),e.getValue());
		System.out.println(linkedMap);
		
		
		
	}

}
