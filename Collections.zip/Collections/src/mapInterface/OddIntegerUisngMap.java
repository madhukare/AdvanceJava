package mapInterface;

import java.util.HashMap;
import java.util.Map;

public class OddIntegerUisngMap {

	public static void main(String[] args) {
		Map<Integer, Integer> map = new HashMap<>();

		int arr[] = { 1, 1, 2, 1, 3, 2, 3, 4, 4, 3, 4, 4, 6 };

		for (int i = 0; i < arr.length; i++) {
			if (map.containsKey(arr[i])) {
				int value = map.get(arr[i]);
				map.put(arr[i], value + 1);
			} else
				map.put(arr[i], 1);
		}
		System.out.println(map);
		System.out.println("-------------Odd Count-------------");

		for (Map.Entry<Integer, Integer> e : map.entrySet()) {
			if (e.getValue() % 2 != 0)
				System.out.println(e.getKey());
		}

	}

}
