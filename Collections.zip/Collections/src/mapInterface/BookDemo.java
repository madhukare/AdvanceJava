package mapInterface;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class BookDemo {

	public static void main(String[] args) {
		
		Book b1 = new Book("Two States", "Chetan Bhagat");
		Book b2 = new Book("Java", "Bala Guruswamy");
		Book b3 = new Book("Half GirlFriend", "Chetan Bhagat");
		Book b4 = new Book("Half GirlFriend", null);
		Book b5 = new Book("Half GirlFriend", null);

		
		Map<Integer, Book> bookMap = new HashMap<>();

		bookMap.put(b1.getId(), b1);
		bookMap.put(b2.getId(), b2);
		bookMap.put(b3.getId(), b3);
		bookMap.put(b4.getId(),b4);
		bookMap.put(b5.getId(),b5);
		
		
		/*Set<Entry<Integer,Book>> entrySet=bookMap.entrySet();
		for(Entry<Integer, Book> e: entrySet)
			System.out.println(e.getValue());*/
		
		for(Map.Entry<Integer, Book> e: bookMap.entrySet())
			System.out.println(e.getValue());
		
	}

}
