package mapInterface;

import java.util.HashMap;
/*package simple1.program;

public class HelloIndia {
	public static void main(String[] args) {
		
		System.out.println("Hello India");

	}

}*/
import java.util.IdentityHashMap;
import java.util.Map;

public class HashAndIdentity {
	public static void main(String[] args) {
		Map<String, String> HashMap = new HashMap<String, String>();

		HashMap.put(new String("a"), "audi");
		HashMap.put(new String("a"), "ferrari");

		System.out.println(HashMap);// Same key content and override the value
		
		Map<String, String> identityHashMap = new IdentityHashMap<String, String>();

		identityHashMap.put(new String("a"), "audi");
		identityHashMap.put(new String("a"), "ferrari");


		System.out.println(identityHashMap);//


	}
}