package mapInterface;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {
		Map<String,String> countryMap=new HashMap<String,String>();
		
		countryMap.put("India", "New Delhi");
		countryMap.put("USA", "Washington DC");
		countryMap.put("China", "Beijing");
		countryMap.put("UK", "London");
		countryMap.put("Nepal", "Katamundu");
		countryMap.put("Nepal", "abc");
		
		System.out.println(countryMap);
		System.out.println("Value :"+countryMap.get("India"));
		System.out.println("Keys: "+countryMap.keySet());
		System.out.println("Values: "+countryMap.values());

		System.out.println("----------KeyValues-----------");
		Set<String>keys=countryMap.keySet();
		for(String k: keys)
			System.out.println(k+ " " +countryMap.get(k));
		
		
		System.out.println("---------Entries----------");
		Set<Entry<String,String>> entrySet=countryMap.entrySet();
		for(Entry<String, String> e: entrySet)
			System.out.println(e.getKey() +"  "+e.getValue());
	}

}
