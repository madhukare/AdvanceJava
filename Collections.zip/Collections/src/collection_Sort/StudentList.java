package collection_Sort;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StudentList {

	public static void main(String[] args) {

		List<Student1> sList = new ArrayList<>();

		sList.add(new Student1(1, "sindhu", 90, 85, 87));
		sList.add(new Student1(5, "nidhi", 78, 85, 95));
		sList.add(new Student1(7, "swetha", 90, 92, 75));
		sList.add(new Student1(10, "uday", 85, 85, 85));
		sList.add(new Student1(2, "madhukar", 90, 95, 77));
		sList.add(new Student1(8, "pravallika", 90, 75, 80));

		Collections.sort(sList);

		for (Student1 s : sList)//to traverse the list
			System.out.println(s);

	}

}
