package collection_Sort;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EmployeeSort {

	public static void main(String[] args) {
		
		List<Employee> elist=new ArrayList<>();
		
		elist.add(new Employee(1, "sindhu", 20000));
		elist.add(new Employee(2, "nidhi", 30000));
		elist.add(new Employee(3, "pravallika", 45000));
		elist.add(new Employee(4, "swetha", 25000));
		
		Collections.sort(elist);
		
		 for(Employee emp: elist)
			 System.out.println(emp);
		
		
	}

}
