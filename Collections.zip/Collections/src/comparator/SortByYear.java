package comparator;

import java.util.Comparator;

public class SortByYear implements Comparator<Movie> {

	@Override
	public int compare(Movie obj1, Movie obj2) {

		return Integer.compare(obj1.getReleasedYear(), obj2.getReleasedYear());
	}

}