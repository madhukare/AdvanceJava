package comparator;

import java.util.Comparator;

public class SortBydirector_name implements Comparator<Movie>{

	@Override
	public int compare(Movie d1, Movie d2) {
		
		return d1.getDirector_name().compareTo(d2.getDirector_name());
	}

}
