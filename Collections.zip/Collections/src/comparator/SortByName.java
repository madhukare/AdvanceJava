package comparator;

import java.util.Comparator;

public class SortByName implements Comparator<Movie>{

	@Override
	public int compare(Movie n1, Movie n2) {
	
		return n1.getName().compareTo(n2.getName());
	}

}
