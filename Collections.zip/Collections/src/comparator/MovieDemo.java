package comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class MovieDemo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int ch = 0;

		List<Movie> mlist = new ArrayList<>();

		mlist.add(new Movie("Bahubali", "Rajamouli", 180, 2014));
		mlist.add(new Movie("saira", "Surendar", 160, 2019));
		mlist.add(new Movie("Rangasthalam", "Sukumar", 170, 2018));
		mlist.add(new Movie("Fida", "ShekarKamula", 180, 2016));
		mlist.add(new Movie("HappyDays", "ShekarKamula", 150, 2006));
		mlist.add(new Movie("Valmiki", "HarishShankar", 165, 2019));
		mlist.add(new Movie("Bahubali-2", "Rajamouli", 180, 2017));
		mlist.add(new Movie("RRR", "Rajamouli", 180, 2020));
		mlist.add(new Movie("Kgf", "Prashanthneel", 160, 2018));
		mlist.add(new Movie("Awe", "PrashanthVarma", 150, 2017));

		while (true) {
			System.out.println("1.Sort By Year");
			System.out.println("2.Sort By Name");
			System.out.println("3.Sort By Director_Name");
			System.out.println("4. Exit");
			System.out.println("Enter your choice");

			ch = sc.nextInt();

			if (ch == 1) {

				Collections.sort(mlist, new SortByYear());
				for (Movie m : mlist)
					System.out.println(m.getReleasedYear());
			} else if (ch == 2) {

				Collections.sort(mlist, new SortByName());
				for (Movie m : mlist)
					System.out.println(m.getName());

			} else if (ch == 3) {

				Collections.sort(mlist, new SortBydirector_name());
				for (Movie m : mlist)
					System.out.println(m.getDirector_name());

			} else if (ch == 4)
				System.exit(0);
			else
				System.out.println("Invalid Input");

		}

	}

}
