package com.client;

import java.sql.SQLException;
import java.util.List;

import com.dao.EmployeeDao;
import com.dto.Employee;

public class ClientApp {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
	
		
		/*List<Employee> li=EmployeeDao.getAllEmployeeDetailsWithdname();
		for (Employee emp:li) {
			System.out.println(emp);
		}*/

		List<Employee> list=EmployeeDao.getEmployeeDetailsWithDno(101);
		for (Employee emp:list) {
			System.out.println(emp);
			//System.out.println(emp.getNo()+" "+emp.getName()+" "+emp.getSal()+" "+emp.getJob()+" "+emp.getDno().getDno()+" "+emp.getDno().getDname());;
		}
		
	}

}
