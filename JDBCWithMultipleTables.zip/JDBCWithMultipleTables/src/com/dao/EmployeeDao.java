package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dto.Department;
import com.dto.Employee;

public class EmployeeDao {

	public static List<Employee> getAllEmployeeDetailsWithdname() throws ClassNotFoundException, SQLException {

		Connection con = ConnectionUtility.getConnection();

		PreparedStatement ps = con
				.prepareStatement("select emp.*,dept.dname from emp inner join dept on emp.dno=dept.dno");

		ResultSet rs = ps.executeQuery();
		Employee e = null;
		Department d = null;
		List<Employee> eList = new ArrayList<Employee>();
		while (rs.next()) {
			e = new Employee();
			e.setNo(rs.getInt(1));
			e.setName(rs.getString(2));
			e.setSal(rs.getInt(3));
			e.setJob(rs.getString(4));
			int dno = rs.getInt(5);
			String dname = rs.getString(6);
			d = new Department(dno, dname);
			e.setDno(d);
			eList.add(e);

		}
		con.close();
		return eList;
	}
	public static List<Employee> getEmployeeDetailsWithDno(int dno) throws ClassNotFoundException, SQLException{
		Connection con=ConnectionUtility.getConnection();
		PreparedStatement ps=con.prepareStatement("select emp.*,dept.dname from emp, dept where emp.dno=dept.dno and dept.dno=?");
		ps.setInt(1, dno);
		ResultSet rs=ps.executeQuery();
		Employee e = null;
		Department d = null;
		List<Employee> eList = new ArrayList<Employee>();
		while (rs.next()) {
			e = new Employee();
			e.setNo(rs.getInt(1));
			e.setName(rs.getString(2));
			e.setSal(rs.getInt(3));
			e.setJob(rs.getString(4));
			d = new Department(rs.getInt(5),rs.getString(6));
			e.setDno(d);
			eList.add(e);

		}
		con.close();
		return eList;
		
	}
}
