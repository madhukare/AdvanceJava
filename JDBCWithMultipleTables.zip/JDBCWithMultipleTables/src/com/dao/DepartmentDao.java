package com.dao;

public class DepartmentDao {

}
