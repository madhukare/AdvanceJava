package com.dto;

public class Employee {

	private int no;
	private String name;
	private int sal;
	private String job;
	private Department dno;

	public Employee() {
		super();
	}

	public Employee(int no, String name, int sal, String job, Department dno) {
		super();
		this.no = no;
		this.name = name;
		this.sal = sal;
		this.job = job;
		this.dno = dno;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSal() {
		return sal;
	}

	public void setSal(int sal) {
		this.sal = sal;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public Department getDno() {
		return dno;
	}

	public void setDno(Department dno) {
		this.dno = dno;
	}

	@Override
	public String toString() {
		return "Employee [no=" + no + ", name=" + name + ", sal=" + sal + ", job=" + job + ", dno=" + dno + "]";
	}

}
