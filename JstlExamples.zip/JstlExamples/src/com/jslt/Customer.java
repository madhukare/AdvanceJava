package com.jslt;

public class Customer {

	private String cName;
	private long cPhone;
	private String cCity;

	public Customer() {
		super();
	}

	public Customer(String cName,long cPhone, String cCity) {
		super();
		this.cName = cName;
		this.cPhone = cPhone;
		this.cCity = cCity;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public long getcPhone() {
		return cPhone;
	}

	public void setcPhone(long cPhone) {
		this.cPhone = cPhone;
	}

	public String getcCity() {
		return cCity;
	}

	public void setcCity(String cCity) {
		this.cCity = cCity;
	}

}
