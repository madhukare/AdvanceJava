package com.client;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String name = request.getParameter("uname");
		String city = request.getParameter("ucity");
		pw.println("Welcome to : " + name);
		pw.println("city is " + city);
		Cookie obj = new Cookie("user", name);
		Cookie obj1 = new Cookie("c", city);
		/*
		 * obj.setMaxAge(60); obj1.setMaxAge(60);
		 */
		response.addCookie(obj);
		response.addCookie(obj1);

		pw.println("<form action='Servlet2' method='get'>");
		pw.print("<input type='submit' value='Go'>");
		pw.print("</form>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
