package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/S2")
public class S2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String EId = (String) request.getAttribute("ID");
		String EName = (String) request.getAttribute("NAME");
		String ESal = (String) request.getAttribute("SALARY");

		PrintWriter out = response.getWriter();
		out.println("Request Data");
		out.println("Id is : " + EId);
		out.println("Name is: " + EName);
		out.println("Salary is: " + ESal);

		out.println("Context Data");
		ServletContext context = getServletContext();
		String id1 = (String) context.getAttribute("a");
		String name1 = (String) context.getAttribute("b");
		String salary1 = (String) context.getAttribute("c");
		out.println(id1);
		out.println(name1);
		out.println(salary1);
		response.setContentType("text/html");
		out.println("<a href='S3'>Click here To go S3</a>");

	}

}
