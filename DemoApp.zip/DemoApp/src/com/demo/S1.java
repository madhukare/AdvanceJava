package com.demo;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/S1")
public class S1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String EId = request.getParameter("id");
		String EName = request.getParameter("name");
		String ESal = request.getParameter("sal");

		request.setAttribute("ID", EId);
		request.setAttribute("NAME", EName);
		request.setAttribute("SALARY", ESal);

		// set in context

		ServletContext context = getServletContext();
		context.setAttribute("a", EId);
		context.setAttribute("b", EName);
		context.setAttribute("c", ESal);

		RequestDispatcher rd = request.getRequestDispatcher("S2");
		rd.forward(request, response);

	}

}
